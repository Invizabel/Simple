import random
import sys
import pygame
from pygame.locals import *

def main():
    # temp variables
    island_width = 128
    island_seed = "Hawaii"
    random.seed(island_seed)
    
    # initialize width and height
    width, height = 640, 480
    # initialize pygame
    pygame.init()

    # pygame dipslay
    screen = pygame.display.set_mode((width, height),pygame.FULLSCREEN)

    # load assets
    golden_brances_image = pygame.image.load("assets/images/golden_branches.png").convert_alpha()
    golden_brances_image = pygame.transform.scale(golden_brances_image, (round(width / 16), round(width / 16)))
    golden_log_image = pygame.image.load("assets/images/golden_log.png").convert_alpha()
    golden_log_image = pygame.transform.scale(golden_log_image, (round(width / 16), round(width / 16)))

    # pygame clock
    clock = pygame.time.Clock()

    # terrain data
    golden_branch_data = []
    golden_log_data = []

    # generate trees
    for _ in range(-island_width,island_width,round(random.random() * 10 * round(width / 16))):
        if _ != -island_width:
            golden_branch_data.append([_,100])
            golden_branch_data.append([_,100-round(width / 16)])
            golden_branch_data.append([_-round(width / 16),100])
            golden_branch_data.append([_+round(width / 16),100])
            golden_branch_data.append([_-round(width / 16),100+round(width / 16)])
            golden_branch_data.append([_+round(width / 16),100+round(width / 16)])
            golden_log_data.append([_,100+round(width / 16)*1])
            golden_log_data.append([_,100+round(width / 16)*2])
            golden_log_data.append([_,100+round(width / 16)*3])

    #print(round(random.random() * 25 * 8))

    while True:
        screen.fill("cyan")
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()

        for x,y in golden_branch_data:
            screen.blit(golden_brances_image, (x,y))

        for x,y in golden_log_data:
            screen.blit(golden_log_image, (x,y))
                
        pygame.display.update()
        clock.tick(60)
    


if __name__ == "__main__":
    main()
